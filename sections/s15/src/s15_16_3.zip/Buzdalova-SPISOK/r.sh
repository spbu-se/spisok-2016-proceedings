#!/bin/bash

LL="moearl-theory"

if [ "$1" != "clean" ];
then
    for L in $LL
    do
        pdflatex $L
        bibtex $L
        pdflatex $L
        pdflatex $L
#        dvips -t letter $L
#        ps2pdf -sPAPERSIZE=letter $L.ps
    done
else
    rm -f *.dvi *.log *.aux *.bbl *.blg *.ps *.sty
    for L in $LL
    do
    	rm -f $L.pdf
   	done
fi
