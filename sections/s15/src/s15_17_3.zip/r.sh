#!/bin/bash

PAPER="thesis"
if [[ "$1" == "clean" ]]
then
    echo "Cleaning paper $PAPER"
    rm -f $PAPER.pdf *.aux *.toc *.blg *.bbl *.log pic/*-converted-to.pdf
else
    echo "Compiling paper $PAPER"
    xelatex $PAPER.tex
    xelatex $PAPER.tex
    xelatex $PAPER.tex

fi
