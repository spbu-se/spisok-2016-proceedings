var fullArray = [] ; 
_. forEach ( clusteredModel, function(value, key) { 
var listByYear = {}; 
listByYear ['year'] = key ; 
listByYear ['article'] = value.article 
fullArray.push(listByYear) ; 
}) ; 
 
doc.setData ({ 
'list' : fullArray 11 }) ; 