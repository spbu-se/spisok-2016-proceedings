app.get('/api/auth/facebook', 
   passport.authenticate('facebook'));

app.get('/api/auth/facebook/callback',
      passport.authenticate('facebook', {
         successRedirect: '/success-redirect',
         failureRedirect: '/failure-redirect'
      }));

app.get('/api/unconnect/facebook', function (req, res) {
      if (!req.user) {
         res.redirect("/");
         return;
      }
      var user = req.user;
      user.facebook = undefined;
      user.save(function (err) {
         res.redirect('/')
      })
   });