app.post('/api/auth/local/login', passport.authenticate('local-login', {
      successRedirect: '/profile',
      failureRedirect: '/about'
   }));

   app.post('/api/auth/local/join', passport.authenticate('local-signup'), 
   	function (req, res) {
      res.redirect('/api/auth/local/verification');
   });