Profile.virtual('password')
   .set(function (password) {
      this.passwordHash = bcrypt.hashSync(password, bcrypt.genSaltSync(32), null);
   });