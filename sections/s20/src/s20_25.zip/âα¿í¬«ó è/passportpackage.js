app.use(passport.initialize());
app.use(passport.session());
var User = require('../models/profile').Profile;
var FacebookStrategy = require('passport-facebook').Strategy;
var VkStrategy = require('passport-vkontakte').Strategy;
var LocalStrategy = require('passport-local').Strategy;