var MongoStore   = require('connect-mongo')(session);
var session      = require('express-session');
app.use(session({
      secret: 'yourkey',
      resave: true,
      saveUninitialized: true,
      store: new MongoStore({mongooseConnection: mongoose})
   }));