passport.use('local-signup', new LocalStrategy({
         usernameField: 'email',
         passwordField: 'password',
         passReqToCallback: true
      },
      function (req, email, password, done) {
         process.nextTick(function () {
            if (req.body.emailUsername == undefined || 
               req.body.emailUsername === true) {
               User.findOne({'local.email': email}, function (err, user) {
                  if (err) {
                     return done(err);
                  }
                  if (user) {
                     return done(err, {message: 'This email has already used'});
                  } else {
                     var newUser = new User();
                     newUser.local.email = email;
                     newUser.local.password = newUser.generateHash(password);
                     newUser.name = req.body.name;
                     newUser.surname = req.body.surname;
                     newUser.organization = req.body.organization;
                     newUser.country = req.body.country;
                     newUser.city = req.body.city;
                     newUser.phoneNo = req.body.phoneNo;
                     newUser.save(function (err) {
                        if (err) {
                           return done(err);
                        }
                        req.session.cookie.maxAge = 31 * 24 * 60 * 60 * 1000;
                        return done(null, newUser);
                     });
                  }
               });
            }
            else {
               User.findOne({'local.username': email}, function (err, user) {
                  if (err) {
                     return done(err);
                  }
                  if (user) {
                     return done(err, {message: 'This email has already used'});
                  } else {
                     var newUser = new User();
                     newUser.local.username = email;
                     newUser.local.password = newUser.generateHash(password);
                     newUser.save(function (err) {
                        if (err) {
                           return done(err);
                        }
                        req.session.cookie.maxAge = 31 * 24 * 60 * 60 * 1000;
                        return done(null, newUser);
                     });
                  }
               });
            }
         })
      }));