var Profile = new Schema({
   local: {
      email: {type: String},
      username: {type: String},
      passwordHash: String,
      verify: {type: Boolean, default: false},
      token: String
   },
   facebook: {
      id: String,
      token: String,
      email: String,
      name: String
   },
   vk: {
      id: String,
      token: String,
      email: String,
      name: String
   },
   name: {type: String},
   surname: {type: String},
   organization: {type: String},
   country: String,
   city: String,
   phoneNo: String,
   role: {type: Number, default: 0},
   registrationDate: {type: Date, default: Date.now},
});

module.exports.Profile = mongoose.model('Profile', Profile);