passport.use('local-login', new LocalStrategy({
         usernameField: 'email',
         passwordField: 'password',
         passReqToCallback: true
      },
      function (req, email, password, done) {
         if (passLimiter.check(req)) {
            User.findOne({
               $or: [
                  {'local.email': email},
                  {'local.username': email}
               ]
            }, function (err, user) {
               if (err) {
                  return done(err);
               }
               if (!user) {
                  return done({message: 'Incorrect email'}, null);
               }
               if (!user.checkPassword(password)) {
                  return done({message: passLimiter.add(req) || 
                  'Incorrect password'}, null);
               }
               if (!user.local.verify) {
                  req.res.json({message: 'Confirm your registration ' +
                  'before entering!', 'type': 'info'});
                  return;
               }
               req.session.cookie.maxAge = req.body.rememberMe ? 31 * 24 
               * 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
               return done(null, user);
            });
         }
         else {
            return done({message: "You are blocked"});
         }
      }));