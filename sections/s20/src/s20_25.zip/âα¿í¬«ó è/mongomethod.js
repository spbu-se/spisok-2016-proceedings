Profile.methods.generateHash = function(password){
   return bcrypt.hashSync(password, bcrypt.genSaltSync(32), null);
};

Profile.methods.checkPassword = function (password) {
   return bcrypt.compareSync(password, this.local.passwordHash);
};