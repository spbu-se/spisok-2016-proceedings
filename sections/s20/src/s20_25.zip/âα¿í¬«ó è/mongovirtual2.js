Profile.virtual('userId')
   .get(function () {
      return this._id;
   });