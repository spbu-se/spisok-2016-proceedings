library("Rssa")
library("lattice")
plot_circle2 <- function(s){
  angle <- function(v1,v2,w1,w2){
    if (((v1^2 + w1^2) != 0) && ((v2^2 + w2^2) != 0)){
      result <- acos((v1*v2 + w1*w2)/(sqrt(v1^2+w1^2)*sqrt(v2^2+w2^2)))
    }
    else { result <- 0}
    return <- result
  }
  idenf_circle <- function(U1, U2){
    optim_t <- function(t){
      v <- U1
      w <- exp(1.0i*2*pi*t)*U2
      temp1 <- (1:(nu(s)-1))
      temp2 <- (1:(nu(s)-1))
      for (i in (1:(nu(s)-1))){
        temp1[i] <- angle(Re(v[i]), Re(v[i+1]), Re(w[i]), Re(w[i+1]))
        temp2[i] <- angle(Im(v[i]), Im(v[i+1]), Im(w[i]), Im(w[i+1]))
      }
      return(sum(var(temp1) + var(temp2)))
    }
    o <- optimize(f = optim_t,interval = c(0,1))
    t <- o$minimum
    print(o$objective)
    return(exp(1.0i*2*pi*t)*U2)
  }
  for (i in (1:(nu(s)-1))){
    s$U[,i+1] <- idenf_circle(s$U[,i], s$U[,i+1])
  }
  #plot(s, type="paired", idx=c(1:1))
  s
}
