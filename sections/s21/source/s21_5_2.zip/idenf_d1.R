library("Rssa")
library("lattice")
plot_d1 <- function(s){
  num <- 5:8
  u <- s$U[,num]
  data <- data.frame(z = as.vector(u), 
                     g = factor(rep(seq_len(ncol(u)),                     
                          each = nrow(u)),
                        labels = paste("U", num)))
  xyplot(Im(z) ~ Re(z) | g, data = data, type = "l", 
         as.table = TRUE, aspect='iso', 
         scales = list(relation = "free", draw = FALSE), layout = c(4, 1))
}
