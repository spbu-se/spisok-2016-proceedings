source("idenf_d1.R")
source("idenf_circle_angle.R")
lattice.options(default.theme =
                  modifyList(standard.theme("pdf", color = TRUE),
                             list(
                               fontsize = list(text = 7, points = 5),
                               layout.heights =
                                 list(top.padding = 0.1,
                                      key.axis.padding = 0.25,
                                      axis.xlab.padding = 0.1,
                                      xlab.key.padding = 0.1,
                                      key.sub.padding = 0.25,
                                      bottom.padding = 0.1),
                               layout.widths =
                                 list(left.padding = 0.1,
                                      key.ylab.padding = 0.1,
                                      ylab.axis.padding = 0.1,
                                      axis.key.padding = 0.1,
                                      right.padding = 1))))
trellis.par.get("fontsize")

set.seed(13)
x <- (exp(0.004*(1:199))*
   (cos(2*pi*(1:199)/5) + 70.0i*cos(2*pi*(1:199)/5+pi/4))+
   10*(cos(2*pi*(1:199)/25) + 
      2.0i*cos(2*pi*(1:199)/25))+
   exp(0.005*(1:199))*
   (cos(2*pi*(1:199)/10) + 1.0i*sin(2*pi*(1:199)/10))+
   1*(rnorm(199,sd=1) + 1.0i*rnorm(199, sd=1)))
s <- ssa(x,
         kind = "cssa", svd.method = "svd", L=100)
plot(s, type="vectors", idx=1:8)

pdf("before2d.pdf",  paper = "special", width = 3, height = 2)
plot(s, type="paired", idx=1:8, plot.contrib = FALSE, layout = c(4, 2))
dev.off()

s1 <- plot_circle2(s)

pdf("after2d.pdf", paper = "special",  width = 3, height = 2)
plot(s1, type="paired", idx=1:8, plot.contrib = FALSE, layout = c(4, 2))
dev.off()

pdf("1d.pdf",  paper = "special", width = 3, height = 1)
plot_d1(s)
dev.off()


